#!/usr/bin/env bash
# LectureMind v2 — Start both servers with one command
set -e

ROOT="$(cd "$(dirname "$0")" && pwd)"

echo ""
echo "🧠  LectureMind v2 Starting..."
echo "================================"

# ── Backend ──────────────────────────────────────────────────────────────────
echo "🐍  Starting Python FastAPI backend on http://localhost:8000"
cd "$ROOT/backend"

if [ ! -f ".env" ]; then
  echo "⚠️   No .env found in backend/. Copying from .env.example..."
  cp .env.example .env
  echo "    → Add your ANTHROPIC_API_KEY to backend/.env"
fi

# Start backend in background
python main.py &
BACKEND_PID=$!
echo "    Backend PID: $BACKEND_PID"

# Give it a moment to boot
sleep 2

# ── Frontend ─────────────────────────────────────────────────────────────────
echo ""
echo "⚡  Starting React frontend on http://localhost:5173"
cd "$ROOT/frontend"

if [ ! -d "node_modules" ]; then
  echo "    Installing npm packages..."
  npm install
fi

npm run dev &
FRONTEND_PID=$!
echo "    Frontend PID: $FRONTEND_PID"

echo ""
echo "================================"
echo "✅  Both servers are running!"
echo "   Frontend: http://localhost:5173"
echo "   Backend:  http://localhost:8000"
echo "   API docs: http://localhost:8000/docs"
echo "================================"
echo "   Press Ctrl+C to stop both"
echo ""

# Wait and cleanup on exit
trap "kill $BACKEND_PID $FRONTEND_PID 2>/dev/null; echo 'Servers stopped.'" EXIT
wait
