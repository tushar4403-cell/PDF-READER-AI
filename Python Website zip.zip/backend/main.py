"""
LectureMind Backend — FastAPI + Python
Endpoints:
  GET  /api/health          — health check
  POST /api/analyze         — upload PDF → extract text → Claude analysis
  POST /api/wallpaper       — generate SVG study wallpaper from topics
  POST /api/flashcards      — generate additional flashcard sets
  POST /api/mindmap         — generate mind-map node data from summary
  POST /api/poem            — generate a study poem / mnemonic from topics
"""

import os
import io
import json
import math
import random
import textwrap
from pathlib import Path

import fitz  # PyMuPDF
import anthropic
from dotenv import load_dotenv
from fastapi import FastAPI, File, UploadFile, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, Response
from pydantic import BaseModel
from typing import List, Optional

# ── env ──────────────────────────────────────────────────────────────────────
load_dotenv()
API_KEY = os.getenv("ANTHROPIC_API_KEY", "")

# ── app ──────────────────────────────────────────────────────────────────────
app = FastAPI(title="LectureMind API", version="2.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── helpers ───────────────────────────────────────────────────────────────────

def get_client() -> anthropic.Anthropic:
    if not API_KEY:
        raise HTTPException(
            status_code=503,
            detail="ANTHROPIC_API_KEY not set. Add it to backend/.env"
        )
    return anthropic.Anthropic(api_key=API_KEY)


def extract_pdf_text(pdf_bytes: bytes) -> tuple[str, int]:
    """Extract text from PDF bytes using PyMuPDF. Returns (text, page_count)."""
    doc = fitz.open(stream=pdf_bytes, filetype="pdf")
    pages = []
    for i, page in enumerate(doc, 1):
        text = page.get_text("text")
        if text.strip():
            pages.append(f"--- Page {i} ---\n{text.strip()}")
    doc.close()

    full_text = "\n\n".join(pages)
    if len(full_text.strip()) < 80:
        raise HTTPException(
            status_code=422,
            detail=(
                "Could not extract readable text from this PDF. "
                "The file may be a scanned image. Please use a PDF with selectable text."
            )
        )
    # Truncate to ~14 000 chars to stay within token limits
    if len(full_text) > 14000:
        full_text = full_text[:14000] + "\n\n[... document truncated ...]"
    return full_text, len(pages)


ANALYSIS_PROMPT = """You are an expert academic AI tutor.
Analyse the lecture text below and return ONLY a single valid JSON object — no markdown fences, no extra text.

JSON structure (follow exactly):
{
  "subject": "Short subject label (e.g. Machine Learning, Quantum Physics)",
  "summary": {
    "overview": "2–3 sentence plain-English overview of the entire lecture",
    "keyPoints": [
      "Full sentence key point 1",
      "Full sentence key point 2",
      "Full sentence key point 3",
      "Full sentence key point 4",
      "Full sentence key point 5"
    ],
    "conclusion": "One sentence capturing the most important takeaway"
  },
  "quiz": {
    "questions": [
      {
        "question": "Question text ending with ?",
        "options": ["Option A", "Option B", "Option C", "Option D"],
        "correct": 0,
        "explanation": "Why the correct answer is right"
      }
    ]
  },
  "flashcards": [
    { "front": "Term or concept", "back": "Clear definition or explanation" }
  ],
  "hardTopics": {
    "topics": [
      {
        "name": "Topic name",
        "difficulty": 8,
        "reason": "Why students find this hard",
        "tips": ["tip 1", "tip 2", "tip 3"]
      }
    ]
  },
  "studyPlan": {
    "days": [
      {
        "day": 1,
        "theme": "Short theme title",
        "totalTime": "2h 30m",
        "topics": ["topic 1"],
        "blocks": [
          { "topic": "Block title", "time": "45 min", "activity": "Specific actionable activity" }
        ]
      }
    ]
  },
  "videos": {
    "videos": [
      {
        "title": "Video title",
        "channel": "Channel name",
        "duration": "MM:SS",
        "description": "What it covers and why it helps",
        "url": "https://www.youtube.com/watch?v=REAL_ID"
      }
    ]
  },
  "mindmap": {
    "root": "Central lecture topic",
    "branches": [
      {
        "label": "Branch name",
        "color": "#6366f1",
        "children": ["sub-topic 1", "sub-topic 2", "sub-topic 3"]
      }
    ]
  },
  "poem": "A 6–8 line rhyming mnemonic poem that helps remember the key ideas. Make it fun and memorable."
}

Hard requirements:
- quiz.questions: EXACTLY 5 items, correct is 0-based index
- flashcards: EXACTLY 8 items — terms/concepts from the lecture
- hardTopics.topics: EXACTLY 3 items, difficulty integer 1–10
- studyPlan.days: EXACTLY 7 days each with 3–4 blocks
- videos.videos: EXACTLY 3 items with REAL YouTube URLs
- mindmap.branches: 4–6 branches each with 2–4 children
- ALL content must come directly from the lecture text
- poem must rhyme and relate to the lecture content

LECTURE TEXT:
"""


# ── routes ───────────────────────────────────────────────────────────────────

@app.get("/api/health")
def health():
    return {
        "status": "ok",
        "api_key_set": bool(API_KEY),
        "version": "2.0.0"
    }


@app.post("/api/analyze")
async def analyze(file: UploadFile = File(...)):
    """Accepts a PDF, extracts text with PyMuPDF, sends to Claude, returns JSON."""
    if not file.filename.lower().endswith(".pdf"):
        raise HTTPException(status_code=400, detail="Only PDF files are accepted.")

    pdf_bytes = await file.read()
    if len(pdf_bytes) > 50 * 1024 * 1024:  # 50 MB guard
        raise HTTPException(status_code=413, detail="PDF too large (max 50 MB).")

    # Extract text
    try:
        text, page_count = extract_pdf_text(pdf_bytes)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=422, detail=f"PDF parsing error: {e}")

    # Call Claude
    client = get_client()
    try:
        message = client.messages.create(
            model="claude-opus-4-6",
            max_tokens=4096,
            messages=[{"role": "user", "content": ANALYSIS_PROMPT + text}],
        )
        raw = "".join(
            block.text for block in message.content if hasattr(block, "text")
        )
        # Strip accidental markdown fences
        cleaned = raw.strip()
        for fence in ["```json", "```"]:
            cleaned = cleaned.replace(fence, "")
        cleaned = cleaned.strip()

        data = json.loads(cleaned)
    except json.JSONDecodeError as e:
        raise HTTPException(
            status_code=500,
            detail=f"Claude returned invalid JSON: {e}. Raw (first 400 chars): {raw[:400]}"
        )
    except anthropic.APIError as e:
        raise HTTPException(status_code=502, detail=f"Anthropic API error: {e}")

    return JSONResponse({"ok": True, "pages": page_count, "data": data})


# ── Wallpaper generator ───────────────────────────────────────────────────────

class WallpaperRequest(BaseModel):
    subject: str
    keyTerms: List[str]
    palette: Optional[str] = "cosmic"  # cosmic | ocean | forest | fire | mono


PALETTES = {
    "cosmic": {
        "bg1": "#080b14", "bg2": "#0d1229", "bg3": "#141833",
        "a1": "#6366f1", "a2": "#22d3ee", "a3": "#a855f7",
        "a4": "#ec4899", "text": "rgba(255,255,255,0.18)",
    },
    "ocean": {
        "bg1": "#020d18", "bg2": "#041428", "bg3": "#061c38",
        "a1": "#0ea5e9", "a2": "#06b6d4", "a3": "#3b82f6",
        "a4": "#8b5cf6", "text": "rgba(255,255,255,0.15)",
    },
    "forest": {
        "bg1": "#030d08", "bg2": "#051410", "bg3": "#071c18",
        "a1": "#10b981", "a2": "#34d399", "a3": "#6ee7b7",
        "a4": "#a7f3d0", "text": "rgba(255,255,255,0.14)",
    },
    "fire": {
        "bg1": "#0f0500", "bg2": "#1a0800", "bg3": "#250c00",
        "a1": "#f97316", "a2": "#ef4444", "a3": "#facc15",
        "a4": "#ec4899", "text": "rgba(255,255,255,0.16)",
    },
    "mono": {
        "bg1": "#0a0a0a", "bg2": "#111111", "bg3": "#1a1a1a",
        "a1": "#ffffff", "a2": "#d4d4d4", "a3": "#a3a3a3",
        "a4": "#737373", "text": "rgba(255,255,255,0.12)",
    },
}


def generate_wallpaper_svg(subject: str, terms: List[str], palette: str) -> str:
    """Generate a 1920×1080 SVG study wallpaper."""
    W, H = 1920, 1080
    p = PALETTES.get(palette, PALETTES["cosmic"])
    rng = random.Random(subject)  # deterministic for same input

    def rand(lo, hi): return rng.uniform(lo, hi)
    def irand(lo, hi): return rng.randint(lo, hi)

    lines = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">',
        '<defs>',
        # Background gradient
        f'<linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">',
        f'  <stop offset="0%" stop-color="{p["bg1"]}"/>',
        f'  <stop offset="50%" stop-color="{p["bg2"]}"/>',
        f'  <stop offset="100%" stop-color="{p["bg3"]}"/>',
        '</linearGradient>',
        # Glow filters
        '<filter id="glow1"><feGaussianBlur stdDeviation="40" result="blur"/>'
        '<feComposite in="SourceGraphic" in2="blur" operator="over"/></filter>',
        '<filter id="glow2"><feGaussianBlur stdDeviation="20" result="blur"/>'
        '<feComposite in="SourceGraphic" in2="blur" operator="over"/></filter>',
        '<filter id="softglow"><feGaussianBlur stdDeviation="8"/></filter>',
        # Text gradient
        f'<linearGradient id="tg" x1="0" y1="0" x2="1" y2="0">',
        f'  <stop offset="0%" stop-color="{p["a1"]}"/>',
        f'  <stop offset="50%" stop-color="{p["a2"]}"/>',
        f'  <stop offset="100%" stop-color="{p["a3"]}"/>',
        '</linearGradient>',
        '</defs>',
        # Background rect
        f'<rect width="{W}" height="{H}" fill="url(#bg)"/>',
    ]

    # ── large blurred orbs ────────────────────────────────────────────────────
    orb_configs = [
        (irand(100,400), irand(100,400), irand(300,500), p["a1"], 0.18),
        (irand(1400,1800), irand(600,900), irand(280,450), p["a3"], 0.15),
        (irand(800,1200), irand(500,800), irand(200,380), p["a2"], 0.12),
        (irand(200,600),  irand(700,1000), irand(180,320), p["a4"], 0.1),
        (irand(1500,1900), irand(100,400), irand(150,280), p["a2"], 0.1),
    ]
    for cx, cy, r, color, opacity in orb_configs:
        lines.append(
            f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="{color}" '
            f'opacity="{opacity}" filter="url(#glow1)"/>'
        )

    # ── geometric shapes grid ─────────────────────────────────────────────────
    shape_colors = [p["a1"], p["a2"], p["a3"], p["a4"]]
    for _ in range(18):
        x = irand(0, W); y = irand(0, H)
        color = rng.choice(shape_colors)
        opacity = round(rand(0.03, 0.12), 3)
        kind = irand(0, 3)
        if kind == 0:  # circle
            r = irand(20, 90)
            lines.append(f'<circle cx="{x}" cy="{y}" r="{r}" fill="none" stroke="{color}" stroke-width="1.5" opacity="{opacity}"/>')
        elif kind == 1:  # hexagon
            s = irand(30, 80)
            pts = " ".join(
                f"{x + s*math.cos(math.radians(60*i+30)):.1f},{y + s*math.sin(math.radians(60*i+30)):.1f}"
                for i in range(6)
            )
            lines.append(f'<polygon points="{pts}" fill="none" stroke="{color}" stroke-width="1.5" opacity="{opacity}"/>')
        else:  # rect
            w2 = irand(30, 100); h2 = irand(30, 100)
            rot = irand(0, 45)
            lines.append(
                f'<rect x="{x-w2//2}" y="{y-h2//2}" width="{w2}" height="{h2}" '
                f'fill="none" stroke="{color}" stroke-width="1.5" opacity="{opacity}" '
                f'transform="rotate({rot} {x} {y})"/>'
            )

    # ── floating particles ────────────────────────────────────────────────────
    for _ in range(60):
        x = irand(0, W); y = irand(0, H)
        r = rand(1, 4)
        color = rng.choice(shape_colors)
        op = round(rand(0.1, 0.5), 2)
        lines.append(f'<circle cx="{x}" cy="{y}" r="{r:.1f}" fill="{color}" opacity="{op}"/>')

    # ── connection lines ──────────────────────────────────────────────────────
    nodes = [(irand(100, W-100), irand(100, H-100)) for _ in range(12)]
    for i, (x1, y1) in enumerate(nodes):
        for x2, y2 in nodes[i+1:i+3]:
            dist = math.hypot(x2-x1, y2-y1)
            if dist < 500:
                op = round(rand(0.04, 0.12), 3)
                lines.append(
                    f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" '
                    f'stroke="{p["a2"]}" stroke-width="1" opacity="{op}"/>'
                )

    # ── scattered key terms (watermark style) ─────────────────────────────────
    font_sizes = [14, 16, 18, 20, 22]
    all_terms = terms[:12] if terms else ["study", "learn", "focus"]
    for _ in range(30):
        term = rng.choice(all_terms)
        x = irand(40, W - 40)
        y = irand(40, H - 40)
        fs = rng.choice(font_sizes)
        rot = irand(-25, 25)
        op = round(rand(0.05, 0.18), 3)
        color = rng.choice(shape_colors)
        lines.append(
            f'<text x="{x}" y="{y}" font-family="monospace" font-size="{fs}" '
            f'fill="{color}" opacity="{op}" '
            f'transform="rotate({rot} {x} {y})">{_escape_svg(term)}</text>'
        )

    # ── centre glow halo ──────────────────────────────────────────────────────
    lines.append(
        f'<circle cx="{W//2}" cy="{H//2}" r="280" fill="{p["a1"]}" '
        f'opacity="0.04" filter="url(#glow1)"/>'
    )

    # ── main subject title ────────────────────────────────────────────────────
    subj_safe = _escape_svg(subject.upper())
    lines += [
        f'<text x="{W//2}" y="{H//2 - 30}" text-anchor="middle" '
        f'font-family="\'Segoe UI\', Arial, sans-serif" font-size="88" font-weight="900" '
        f'fill="url(#tg)" opacity="0.92" letter-spacing="8">{subj_safe}</text>',
    ]

    # ── subtitle ─────────────────────────────────────────────────────────────
    lines.append(
        f'<text x="{W//2}" y="{H//2 + 38}" text-anchor="middle" '
        f'font-family="\'Segoe UI\', Arial, sans-serif" font-size="22" font-weight="400" '
        f'fill="{p["a2"]}" opacity="0.65" letter-spacing="6">STUDY WALLPAPER  ·  LECTUREMIND AI</text>'
    )

    # ── key terms row at bottom ───────────────────────────────────────────────
    display_terms = terms[:8]
    if display_terms:
        total_w = len(display_terms) * 180
        start_x = (W - total_w) // 2 + 90
        for i, term in enumerate(display_terms):
            tx = start_x + i * 180
            ty = H - 80
            color = shape_colors[i % len(shape_colors)]
            lines += [
                f'<rect x="{tx-70}" y="{ty-22}" width="140" height="32" rx="16" '
                f'fill="{color}" opacity="0.12" stroke="{color}" stroke-width="1" stroke-opacity="0.3"/>',
                f'<text x="{tx}" y="{ty}" text-anchor="middle" '
                f'font-family="monospace" font-size="13" fill="{color}" opacity="0.8">{_escape_svg(term)}</text>',
            ]

    # ── corner accent lines ───────────────────────────────────────────────────
    for (cx, cy, dx, dy) in [(0,0,1,1),(W,0,-1,1),(0,H,1,-1),(W,H,-1,-1)]:
        for j in range(1, 6):
            op = round(0.08 - j*0.012, 3)
            l = j * 60
            lines.append(
                f'<line x1="{cx}" y1="{cy}" '
                f'x2="{cx + dx*l}" y2="{cy + dy*l//3}" '
                f'stroke="{p["a1"]}" stroke-width="{7-j}" opacity="{op}"/>'
            )

    lines.append('</svg>')
    return "\n".join(lines)


def _escape_svg(s: str) -> str:
    return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace('"',"&quot;")


@app.post("/api/wallpaper")
async def wallpaper(req: WallpaperRequest):
    svg = generate_wallpaper_svg(req.subject, req.keyTerms, req.palette)
    return JSONResponse({"ok": True, "svg": svg})


# ── Flashcard extra generator ─────────────────────────────────────────────────

class FlashcardRequest(BaseModel):
    subject: str
    existingTerms: List[str]


@app.post("/api/flashcards")
async def more_flashcards(req: FlashcardRequest):
    client = get_client()
    prompt = (
        f"Generate 6 new flashcards for the subject '{req.subject}'. "
        f"Already covered: {', '.join(req.existingTerms[:8])}. "
        "Return ONLY a JSON array of objects with 'front' and 'back' keys. No markdown."
    )
    try:
        msg = client.messages.create(
            model="claude-opus-4-6",
            max_tokens=800,
            messages=[{"role": "user", "content": prompt}]
        )
        raw = "".join(b.text for b in msg.content if hasattr(b, "text"))
        raw = raw.replace("```json","").replace("```","").strip()
        cards = json.loads(raw)
        return JSONResponse({"ok": True, "cards": cards})
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ── Poem / mnemonic generator ─────────────────────────────────────────────────

class PoemRequest(BaseModel):
    subject: str
    keyPoints: List[str]


@app.post("/api/poem")
async def generate_poem(req: PoemRequest):
    client = get_client()
    prompt = (
        f"Write a fun, rhyming 8-line mnemonic poem about '{req.subject}' "
        f"that helps students remember these key ideas: {'; '.join(req.keyPoints[:5])}. "
        "Make it memorable, slightly humorous, and educational. "
        "Return ONLY the poem as plain text, no title, no explanation."
    )
    try:
        msg = client.messages.create(
            model="claude-opus-4-6",
            max_tokens=300,
            messages=[{"role": "user", "content": prompt}]
        )
        poem = "".join(b.text for b in msg.content if hasattr(b, "text")).strip()
        return JSONResponse({"ok": True, "poem": poem})
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ── Mindmap data endpoint ─────────────────────────────────────────────────────

class MindmapRequest(BaseModel):
    subject: str
    overview: str


@app.post("/api/mindmap")
async def generate_mindmap(req: MindmapRequest):
    client = get_client()
    prompt = (
        f"Create a mind map for '{req.subject}'. Overview: {req.overview}\n"
        "Return ONLY JSON: {\"root\":\"Central topic\",\"branches\":[{\"label\":\"Branch\","
        "\"color\":\"#hexcode\",\"children\":[\"sub1\",\"sub2\",\"sub3\"]}]}\n"
        "Include 5 branches, each with 3 children. Use varied hex colours."
    )
    try:
        msg = client.messages.create(
            model="claude-opus-4-6",
            max_tokens=600,
            messages=[{"role": "user", "content": prompt}]
        )
        raw = "".join(b.text for b in msg.content if hasattr(b, "text"))
        raw = raw.replace("```json","").replace("```","").strip()
        data = json.loads(raw)
        return JSONResponse({"ok": True, "mindmap": data})
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
